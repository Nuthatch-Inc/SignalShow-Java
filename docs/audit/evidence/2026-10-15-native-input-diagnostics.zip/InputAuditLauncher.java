import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

/** Temporary diagnostic only; records event types/focus, never typed characters. */
public class InputAuditLauncher {
  private static PrintStream log;
  static String type(Object value) { return value == null ? "null" : value.getClass().getSimpleName(); }
  public static void main(String[] args) throws Exception {
    log = new PrintStream(new FileOutputStream(System.getProperty("input.audit.log")), true);
    System.setErr(log);
    log.println("runtime="+System.getProperty("java.runtime.version")+" home="+System.getProperty("java.home"));
    Toolkit.getDefaultToolkit().addAWTEventListener(event -> {
      if (event instanceof KeyEvent || event instanceof FocusEvent || event instanceof WindowEvent ||
          event instanceof MouseEvent mouse && mouse.getID() == MouseEvent.MOUSE_PRESSED) {
        KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
        log.println("event="+type(event)+":"+event.getID()+" source="+type(event.getSource())+
          " focus="+type(manager.getFocusOwner())+" window="+type(manager.getFocusedWindow())+
          " active="+type(manager.getActiveWindow()));
        if (event instanceof MouseEvent mouse && mouse.getComponent() instanceof javax.swing.text.JTextComponent field) {
          log.println("text showing="+field.isShowing()+" enabled="+field.isEnabled()+" editable="+field.isEditable()+
            " ancestor="+type(SwingUtilities.getWindowAncestor(field)));
          for (AWTEventListener listener : Toolkit.getDefaultToolkit().getAWTEventListeners(AWTEvent.MOUSE_EVENT_MASK))
            log.println("listener="+((AWTEventListenerProxy)listener).getListener().getClass().getName());
        }
      }
    }, AWTEvent.KEY_EVENT_MASK | AWTEvent.FOCUS_EVENT_MASK | AWTEvent.WINDOW_EVENT_MASK |
       AWTEvent.WINDOW_FOCUS_EVENT_MASK | AWTEvent.MOUSE_EVENT_MASK);
    if (!Boolean.getBoolean("input.audit.probe")) { SignalShow.main(args); return; }
    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    SwingUtilities.invokeLater(() -> {
      JFrame frame = new JFrame("SignalShow Swing Input Probe");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      JPanel panel = new JPanel(new GridLayout(3, 2, 12, 12));
      panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
      JTextField first = new JTextField("alpha", 20), second = new JTextField("beta",20);
      JSpinner number = new JSpinner(new SpinnerNumberModel(1.0,-1000.0,1000.0,.1));
      JComponent[] controls = {first, second, number};
      String[] names = {"Plain text", "Second text", "Number"};
      for(int i=0;i<controls.length;i++) {
        JLabel label = new JLabel(names[i]); label.setLabelFor(controls[i]);
        controls[i].getAccessibleContext().setAccessibleName(names[i]);
        panel.add(label); panel.add(controls[i]);
      }
      frame.add(panel); frame.pack(); frame.setLocation(250,200); frame.setVisible(true);
      if(Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.APP_REQUEST_FOREGROUND))
        Desktop.getDesktop().requestForeground(false);
    });
  }
}
